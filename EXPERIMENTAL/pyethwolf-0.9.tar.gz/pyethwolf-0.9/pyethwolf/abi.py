import binascii
import cStringIO
import decimal
import os
import re
import struct

import sha3

# This will turn whatever you've got into a codec object. It can take:
#   - string or unicode
#   - any kind of a list where each element in the list is a dictionary which
#     has a 'type' field. It'll assume that it represents a tuple, or a
#     sufficiently tuple-like thing such as a list of function inputs or
#     outputs.
def make_abi_codec(snippet):
    if isinstance(snippet, unicode):
        snippet = snippet.encode('us-ascii')
    elif not isinstance(snippet, str):
        def stringification_helper(x):
            contents = []
            for elem in snippet:
                elem_type = elem['type']
                if isinstance(elem_type, unicode):
                    elem_type = elem_type.encode('us-ascii')
                if elem_type.startswith('tuple'):
                    elem_type = stringification_helper(elem['components']) + \
                                elem_type[5:]
                contents.append(elem_type)
            return '(' + ','.join(contents) + ')'
        snippet = stringification_helper(snippet)

    (t, snippet) = _translate_one_abi_type(snippet.strip())
    if snippet != '':
        raise Exception('garbage at end')

    return t

# Instances of AbiCodec will always have the following attributes:
#   - dynamic: Boolean indicating whether the codec is dynamic as defined
#     by <https://solidity.readthedocs.io/en/develop/abi-spec.html>
#   - type_str: Canonical string representation of the type represented by
#     this AbiCodec, suitable for using in a function signature
# Instances of AbiCodec will always have the following methods:
#   - encode(obj) -> str
#   - decode(str) -> obj
#   - function_signature(function_name) -> str
#   - truncated_hashed_function_signature(function_name) -> str
class AbiCodec (object):
    @property
    def dynamic(self):
        return (self._size is None)

    def encode(self, obj):
        chunks = []
        self._encode_into(obj, chunks)
        return ''.join(chunks)

    def decode(self, s):
        if isinstance(s, unicode):
            raise ValueError(s)
        f = cStringIO.StringIO(s)
        obj = self._decode_from(f)
        if f.read(1) != '':
            raise Exception('garbage at end of input')
        return obj

    def function_signature(self, name):
        return name + self.type_str

    def truncated_hashed_function_signature(self, name):
        digester = sha3.keccak_256()
        digester.update(self.function_signature(name))
        return digester.digest()[:4]

    # If you're dynamic, you must implement your own _skip().
    def _skip(self, f, nelems):
        assert(self._size is not None)
        f.seek(self._size * nelems, os.SEEK_CUR)

    @staticmethod
    def _read_exact(f, nbytes):
        if nbytes == 0:
            return ''
        s = f.read(nbytes)
        if len(s) != nbytes:
            raise Exception('unexpected EOF')
        return s

class AbiCodecUint (AbiCodec):
    _size = 32
    _base_type_str = 'uint'
    _struct_fmt_char_encode = 'Q'
    _struct_fmt_char_decode_first = 'Q'
    _struct_fmt_char_decode_rest = 'Q'
    _padding_byte_pos = '\x00'
    _padding_byte_neg = '\x00'
    def __init__(self, nbits):
        if (nbits <= 0) or (nbits > 256) or ((nbits % 8) != 0):
            raise ValueError(nbits)
        num_fields_needed = (nbits + 63) // 64
        self._num_significant_bytes = num_fields_needed * 8

        self.type_str = self._base_type_str + '%d' % (nbits,)

        self._num_insignificant_bytes = self._size - (num_fields_needed * 8)
        self._padding_pos = \
            self._padding_byte_pos * self._num_insignificant_bytes
        self._padding_neg = \
            self._padding_byte_neg * self._num_insignificant_bytes

        fmt_str = '!' + (self._struct_fmt_char_encode * num_fields_needed)
        self._struct_for_encoding = struct.Struct(fmt_str)

        fmt_str = '!' + self._struct_fmt_char_decode_first + \
                  (self._struct_fmt_char_decode_rest * (num_fields_needed - 1))
        self._struct_for_decoding = struct.Struct(fmt_str)

        self._shift_by = \
            [(i * 64) for i in xrange(num_fields_needed - 1, -1, -1)]

    def _encode_into(self, i, chunks):
        chunks.append(self._padding_pos if i >= 0 else self._padding_neg)
        fields = [((i >> shift_by) &
                   0xffffffffffffffffL) for shift_by in self._shift_by]
        chunks.append(self._struct_for_encoding.pack(*fields))
        return self._size

    def _decode_from(self, f):
        f.seek(self._num_insignificant_bytes, os.SEEK_CUR)
        fields = iter(self._struct_for_decoding.unpack(
                          self._read_exact(f, self._num_significant_bytes)))
        i = fields.next()
        for x in fields:
            i = (i << 64) | x
        return i

class AbiCodecInt (AbiCodecUint):
    _base_type_str = 'int'
    _struct_fmt_char_decode_first = 'q'
    _padding_byte_neg = '\xff'

class AbiCodecAddress (AbiCodec):
    _size = 32
    type_str = 'address'

    _padding = '\x00' * 12
    def _encode_into(self, addr, chunks):
        if addr.startswith('0x') or addr.startswith('0X'):
            addr = addr[2:]
        as_binary = binascii.a2b_hex(addr)
        if len(as_binary) != 20:
            raise ValueError(addr)

        chunks.append(self._padding)
        chunks.append(as_binary)
        return self._size

    def _decode_from(self, f):
        f.seek(12, os.SEEK_CUR)
        as_binary = self._read_exact(f, 20)
        return '0x' + binascii.b2a_hex(as_binary)

class AbiCodecBool (AbiCodec):
    _size = 32
    type_str = 'bool'

    _true_val = ('\x00' * 31) + '\x01'
    _false_val = ('\x00' * 31) + '\x00'
    def _encode_into(self, b, chunks):
        chunks.append(self._true_val if b else self._false_val)
        return self._size

    def _decode_from(self, f):
        f.seek(31, os.SEEK_CUR)
        return (self._read_exact(f, 1) != '\x00')

def _fixed_calculate_p10_and_q(n):
    if n < 0:
        raise ValueError(n)
    p10 = decimal.Decimal('1' + ('0' * n))
    if n == 0:
        q = decimal.Decimal('1')
    else:
        q = decimal.Decimal('0.' + ('0' * (n - 1)) + '1')
    return (p10, q)

def _fixed_prepare_for_encode(d, p10, q):
    return long(d.quantize(q) * p10)

def _fixed_convert_after_decode(i, q):
    return (decimal.Decimal(i).quantize(q) * q).quantize(q)

class AbiCodecFixed (AbiCodecInt):
    def __init__(self, m, n):
        # We could pass 'm' in as the number of bits, but the spec seems to
        # indicate that for packing purposes, we always use 256.
        super(AbiCodecFixed, self).__init__(self, 256)
        self.type_str = 'fixed%dx%d' % (m, n)
        (self._p10, self._q) = _fixed_calculate_p10_and_q(n)

    def _encode_into(self, d, chunks):
        i = _fixed_prepare_for_encode(d, self._p10, self._q)
        return super(AbiCodecFixed, self)._encode_into(i, chunks)

    def _decode_from(self, f):
        i = super(AbiCodecFixed, self)._decode_from(f)
        return _fixed_convert_after_decode(i, self._q)

class AbiCodecUfixed (AbiCodecUint):
    def __init__(self, m, n):
        # We could pass 'm' in as the number of bits, but the spec seems to
        # indicate that for packing purposes, we always use 256.
        super(AbiCodecUfixed, self).__init__(self, 256)
        self.type_str = 'ufixed%dx%d' % (m, n)
        (self._p10, self._q) = _fixed_calculate_p10_and_q(n)

    def _encode_into(self, d, chunks):
        i = _fixed_prepare_for_encode(d, self._p10, self._q)
        return super(AbiCodecFixed, self)._encode_into(i, chunks)

    def _decode_from(self, f):
        i = super(AbiCodecFixed, self)._decode_from(f)
        return _fixed_convert_after_decode(i, self._q)

class AbiCodecBytesStatic (AbiCodec):
    _size = 32
    _padding_by_len = ['\x00' * i for i in xrange(32, -1, -1)]

    def __init__(self, nbytes):
        if (nbytes <= 0) or (nbytes > 32):
            raise ValueError(nbytes)
        self.type_str = 'bytes%d' % (nbytes,)
        self._num_significant_bytes = nbytes
        self._num_insignificant_bytes = self._size - nbytes

    def _encode_into(self, s, chunks):
        if isinstance(s, unicode) or (not isinstance(s, str)) or \
           (len(s) > self._size):
            raise ValueError(s)
        chunks.append(s)
        chunks.append(self._padding_by_len[len(s)])
        return self._size

    def _decode_from(self, f):
        s = self._read_exact(f, self._num_significant_bytes)
        f.seek(self._num_insignificant_bytes, os.SEEK_CUR)
        return s

class AbiCodecFunction (AbiCodec):
    _size = 32
    type_str = 'function'

    _padding = '\x00' * 8
    def _encode_into(self, (addr, selector), chunks):
        addr_as_binary = binascii.a2b_hex(addr)
        if len(addr_as_binary) != 20:
            raise ValueError(addr)
        if len(selector) != 4:
            raise ValueError(selector)

        chunks.append(addr_as_binary)
        chunks.append(selector)
        chunks.append(self._padding)
        return self._size

    def _decode_from(self, f):
        addr_as_binary = self._read_exact(f, 20)
        selector = self._read_exact(f, 4)
        f.seek(8, os.SEEK_CUR)
        return (binascii.b2a_hex(addr_as_binary), selector)

class AbiCodecTuple (AbiCodec):
    _len_codec = AbiCodecUint(256)
    def __init__(self, codecs):
        self._codecs = list(codecs)
        self._size = 0
        self._head_size = 0
        self._last_dynamic_codec = None
        self._last_dynamic_headoff = None
        for codec in self._codecs:
            if codec.dynamic:
                self._last_dynamic_codec = codec
                self._last_dynamic_headoff = self._head_size
                self._head_size += self._len_codec._size
                self._size = None
            else:
                self._head_size += codec._size
                if self._size is not None:
                    self._size += codec._size
        self.type_str = \
            '(' + \
            ','.join([codec.type_str for codec in self._codecs]) + \
            ')'

    def _encode_into(self, objs, chunks):
        # In case 'objs' is a generator or something, we don't want to rely
        # on being able to index into it, or even rely on it having a
        # __len__(). So we just iterate it once and keep track of the index
        # we're at.
        nbytes = self._head_size
        nelems = 0
        tails = []
        for obj in objs:
            codec = self._codecs[nelems]
            nelems += 1
            if codec.dynamic:
                self._len_codec._encode_into(nbytes, chunks)
                nbytes += codec._encode_into(obj, tails)
            else:
                codec._encode_into(obj, chunks)

        if nelems != len(self._codecs):
            raise Exception('wrong number of elements in input')

        chunks.extend(tails)

        return nbytes

    def _decode_from(self, f):
        objs = []
        for codec in self._codecs:
            if codec.dynamic:
                self._len_codec._skip(f, 1)
                objs.append(None)
            else:
                objs.append(codec._decode_from(f))
        for (idx, codec) in enumerate(self._codecs):
            if codec.dynamic:
                objs[idx] = codec._decode_from(f)
        return objs

    def _skip(self, f, nelems):
        if not self.dynamic:
            super(AbiCodecTuple, self)._skip(f, nelems)
            return

        for i in xrange(nelems):
            # We *almost* know what the size of the whole tail is. But we don't
            # quite know that. We know the offset of the last dynamic part of
            # the head.
            f.seek(self._last_dynamic_headoff, os.SEEK_CUR)
            last_dynamic_tailoff = self._len_codec._decode_from(f)

            # That was an offset from the beginning. But we've already consumed
            # some of that.
            to_seek = last_dynamic_tailoff - self._last_dynamic_headoff - \
                      self._len_codec._size
            f.seek(to_seek, os.SEEK_CUR)

            # But we're still not done, because we actually have to consume
            # that last tail element.
            self._last_dynamic_codec._skip(f, 1)

# We could have done this by inheriting from AbiCodecTuple, but if we do it
# as its own separate thing, the code actually gets simpler since we know up
# front whether we're "all dynamic" or "all static". We're never "mixed
# dynamic and static".
class AbiCodecFixedLengthArray (AbiCodec):
    _len_codec = AbiCodecUint(256)
    def __init__(self, codec, nelems):
        self._codec = codec
        self._nelems = nelems
        if nelems == 0:
            self._size = 0
        elif codec.dynamic:
            self._size = None
        else:
            self._size = codec._size * nelems
        self.type_str = codec.type_str + \
                        '[%d]' % (nelems,)

    def _encode_into(self, objs, chunks):
        nelems = 0
        if self._codec.dynamic:
            nbytes = self._len_codec._size * self._nelems
            tails = []
            for obj in objs:
                nelems += 1
                self._len_codec._encode_into(nbytes, chunks)
                nbytes += self._codec._encode_into(obj, tails)
            chunks.extend(tails)
        else:
            for obj in objs:
                nelems += 1
                self._codec._encode_into(obj, chunks)
            nbytes = self._size

        if nelems != self._nelems:
            raise Exception('wrong number of elements in input')

        return nbytes

    def _decode_from(self, f):
        if self._codec.dynamic:
            self._len_codec._skip(f, self._nelems)
        return [self._codec._decode_from(f) for i in xrange(self._nelems)]

    def _skip(self, f, nelems):
        if not self.dynamic:
            super(AbiCodecFixedLengthArray, self)._skip(f, nelems)
            return

        for i in xrange(nelems):
            # We *almost* know what the size of the whole tail is. But we don't
            # quite know that. We know the offset of the last part of the head.
            f.seek(self._len_codec._size * (self._nelems - 1), os.SEEK_CUR)
            last_dynamic_tailoff = self._len_codec._decode_from(f)

            # That was an offset from the beginning. But we've already consumed
            # some of that. We've consumed the whole head, to be precise.
            to_seek = \
                last_dynamic_tailoff - (self._len_codec._size * self._nelems)
            f.seek(to_seek, os.SEEK_CUR)

            # But we're still not done, because we actually have to consume
            # that last tail element.
            self._codec._skip(f, 1)

class AbiCodecVarLengthArray (AbiCodec):
    _len_codec = AbiCodecUint(256)
    def __init__(self, codec):
        self._codec = codec
        self._size = None
        self.type_str = codec.type_str + '[]'

    def _encode_into(self, objs, chunks):
        # We only want to iterate 'objs' once, in case it's a generator or
        # something. And we don't want to rely on it having a __len__(). So
        # we encode into a temporary chunks list, and keep track of how many
        # we actually saw.
        #
        # Also, neither the dynamic nor the static case counts the bytes
        # used for the number of elements at the start, in 'nbytes'. In the
        # dynamic case, this is actually important, as described below. But
        # it makes it more consistent if we always add that at the very
        # end just before returning to our caller.

        temp_chunks = []
        if self._codec.dynamic:
            raw_lengths = []
            for obj in objs:
                raw_lengths.append(self._codec._encode_into(obj, temp_chunks))
            nelems = len(raw_lengths)

            # Now we know how many there are, we can put that right into
            # chunks.
            self._len_codec._encode_into(nelems, chunks)

            # Careful, the offsets we put into the heads need to *not*
            # include the number of elements we just put into chunks. We'll
            # have to account for those bytes later, at the very end.
            nbytes = self._len_codec._size * nelems
            for raw_length in raw_lengths:
                self._len_codec._encode_into(nbytes, chunks)
                nbytes += raw_length
        else:
            nelems = 0
            for obj in objs:
                nelems += 1
                self._codec._encode_into(obj, temp_chunks)
            self._len_codec._encode_into(nelems, chunks)
            nbytes = self._codec._size * nelems

        chunks.extend(temp_chunks)
        return nbytes + self._len_codec._size

    def _decode_from(self, f):
        nelems = self._len_codec._decode_from(f)
        if self._codec.dynamic:
            self._len_codec._skip(f, nelems)
        return [self._codec._decode_from(f) for i in xrange(nelems)]

    def _skip(self, f, nelems):
        if self._codec.dynamic:
            for i in xrange(nelems):
                this_nelems = self._len_codec._decode_from(f)
                if this_nelems <= 0:
                    continue

                # We *almost* know what the size of the whole tail is. But we
                # don't quite know that. We know the offset of the last part of
                # the head.
                f.seek(self._len_codec._size * (this_nelems - 1), os.SEEK_CUR)
                last_dynamic_tailoff = self._len_codec._decode_from(f)

                # That was an offset from the beginning. But we've already
                # consumed some of that. We've consumed the whole head, to be
                # precise.
                to_seek = \
                    last_dynamic_tailoff - \
                    (self._len_codec._size * this_nelems)
                f.seek(to_seek, os.SEEK_CUR)

                # But we're still not done, because we actually have to consume
                # that last tail element.
                self._codec._skip(f, 1)
        else:
            for i in xrange(nelems):
                this_nelems = self._len_codec._decode_from(f)
                self._codec._skip(f, this_nelems)

class AbiCodecBytesDynamic (AbiCodec):
    _size = None
    type_str = 'bytes'
    _len_codec = AbiCodecUint(256)
    _padding_by_mod = [(0, '')] + [(i, '\x00' * i) for i in xrange(31, 0, -1)]

    def _encode_into(self, s, chunks):
        if isinstance(s, unicode) or not isinstance(s, str):
            raise ValueError(s)

        nbytes = len(s)
        nbytes += self._len_codec._encode_into(nbytes, chunks)
        chunks.append(s)

        (padding_len, padding) = self._padding_by_mod[nbytes % 32]
        nbytes += padding_len
        chunks.append(padding)

        return nbytes

    def _decode_from(self, f):
        nbytes = self._len_codec._decode_from(f)
        s = self._read_exact(f, nbytes)
        nbytes += self._len_codec._size
        (padding_len, padding) = self._padding_by_mod[nbytes % 32]
        f.seek(padding_len, os.SEEK_CUR)
        return s

    def _skip(self, f, nelems):
        for i in xrange(nelems):
            nbytes = self._len_codec._decode_from(f)
            (padding_len, padding) = \
                self._padding_by_mod[(nbytes + self._len_codec._size) % 32]
            f.seek(nbytes + padding_len, os.SEEK_CUR)

class AbiCodecString (AbiCodecBytesDynamic):
    type_str = 'string'
    def _encode_into(self, u, chunks):
        if not isinstance(u, unicode):
            raise ValueError(u)
        return super(AbiCodecString,
                     self)._encode_into(u.encode('utf-8'), chunks)

    def _decode_from(self, f):
        s = super(AbiCodecString, self)._decode_from(f)
        return s.decode('utf-8')

# This regexp consumes one type from the start of the string, and returns
# to you anything that comes after, in the string. 
#
# It does not handle:
#
#   - fixed-length arrays: <type>[M]
#   - variable-length arrays: <type>[]
#   - tuples: (T1,T2,...,Tn)
#
# so it needs some cooperating python code to handle those things.
_abi_type_re = \
    re.compile(
        r'^(?:'
        r'uint(\d+)|' # uint<M>, e.g. uint32, uint8, uint256
        r'int(\d+)|' # int<M>, e.g. int32, int8, int256
        r'address()|' # address (encoded as if it were uint160)
        r'uint()|' # alias for uint256
        r'int()|' # alias for int256
        r'bool()|' # bool (encoded as if it were uint8)
        r'fixed(\d+)x(\d+)|' # signed fixed-point, e.g. fixed128x18
        r'ufixed(\d+)x(\d+)|' # unsigned fixed-point, e.g. ufixed128x18
        r'fixed()|' # alias for fixed128x18
        r'ufixed()|' # alias for ufixed128x18
        r'bytes(\d+)|' # bytes<M>, e.g. bytes32
        r'function()|' # function (encoded as if it were bytes24)
        r'bytes()|' # bytes
        r'string()' # string
        r')\s*(.*?)\s*$',
        re.IGNORECASE
    )

# This regexp consumes the first array specifier from the string, if one is
# present. It also returns everything left at the end of the string.
_abi_array_re = \
    re.compile(
        r'^\['
        r'(\d+)?'
        r'\]\s*(.*?)\s*$'
    )

def _translate_one_abi_type(snippet):
    snippet = snippet.strip()
    if snippet.startswith('('):
        snippet = snippet[1:].strip()
        contents = []
        while not snippet.startswith(')'):
            (t, snippet) = _translate_one_abi_type(snippet)
            contents.append(t)
            if snippet.startswith(','):
                snippet = snippet[1:].strip()
            elif not snippet.startswith(')'):
                raise ValueError(snippet)
        snippet = snippet[1:].strip()
        t = AbiCodecTuple(contents)
    else:
        m = _abi_type_re.match(snippet)
        (g_uint, g_int, g_address, g_uintdefault, g_intdefault, g_bool,
         g_fixedm, g_fixedn, g_ufixedm, g_ufixedn, g_fixeddefault,
         g_ufixeddefault, g_bytesstatic, g_function, g_bytesdynamic, g_string,
         snippet) = m.groups()
        if g_uint is not None:
            t = AbiCodecUint(int(g_uint))
        elif g_int is not None:
            t = AbiCodecInt(int(g_int))
        elif g_address is not None:
            t = AbiCodecAddress()
        elif g_uintdefault is not None:
            t = AbiCodecUint(256)
        elif g_intdefault is not None:
            t = AbiCodecInt(256)
        elif g_bool is not None:
            t = AbiCodecBool()
        elif g_fixedm is not None:
            t = AbiCodecFixed(int(g_fixedm), int(g_fixedm))
        elif g_ufixedm is not None:
            t = AbiCodecUfixed(int(g_ufixedm), int(g_ufixedm))
        elif g_fixeddefault is not None:
            t = AbiCodecFixed(128, 18)
        elif g_ufixeddefault is not None:
            t = AbiCodecUfixed(128, 18)
        elif g_bytesstatic is not None:
            t = AbiCodecBytesStatic(int(g_bytesstatic))
        elif g_function is not None:
            t = AbiCodecFunction()
        elif g_bytesdynamic is not None:
            t = AbiCodecBytesDynamic()
        elif g_string is not None:
            t = AbiCodecString()
        else:
            raise AssertionError

    while True:
        m = _abi_array_re.match(snippet)
        if m is None:
            break
        (fixed_length_array, snippet) = m.groups()
        if fixed_length_array is not None:
            t = AbiCodecFixedLengthArray(t, int(fixed_length_array))
        else:
            t = AbiCodecVarLengthArray(t)

    return (t, snippet)
