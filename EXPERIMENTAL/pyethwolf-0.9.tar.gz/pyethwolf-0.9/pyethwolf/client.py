import binascii
import json
import os
import struct
import time
import urllib2

import pyethwolf.abi
import pyethwolf.exceptions

# Addresses are represented *with* the 0x prefix. If you pass in an
# address that lacks the prefix, it will be normalized to have the prefix.

class Client (object):
    _rpc_ver = '2.0'
    def __init__(self, gas_price_multiplier=1.0, url='http://localhost:8545/',
                 timeout=120, gas_multiplier=2.0):
        self.gas_multiplier = float(gas_multiplier)
        self.gas_price_multiplier = float(gas_price_multiplier)
        self.url = url
        self.timeout = timeout

    # Parameters:
    #   - `contract_address`: Address of contract
    #   - `abi`: ABI specification (you must decode the JSON first)
    # Returns:
    # `contract`, where:
    #   - `contract`: Object representing contract
    def contract(self, contract_address, abi):
        return Contract(self, contract_address, abi)

    # Parameters:
    #   - `account`: Ethereum address to unlock
    #   - `duration`: Number of seconds to unlock account for
    #     (if None, will unlock permanently -- please don't do this!)
    # Returns:
    # `successfully_unlocked`, where:
    #   - `successfully_unlocked`: Boolean indicating success or failure
    def unlock_account(self, account, passphrase, duration):
        if duration is None:
            duration = 0
        return self._request('personal_unlockAccount',
                             account, passphrase, duration)

    # This method is really meant to be called from the Contract, not
    # raw like this.
    def _inspect_contract(self, account, contract_address, data):
        req = {'from': self.encode_address(account),
               'to': self.encode_address(contract_address),
               'data': self.encode_binary(data),
              }
        return self.decode_binary(self._request('eth_call', req, 'latest'))

    # This method is really meant to be called from the Contract, not
    # raw like this. It returns (transaction_hash, block_num, block_hash)
    def _mutate_contract(self, account, contract_address, data, value):
        req = {'from': self.encode_address(account),
               'to': self.encode_address(contract_address),
               'data': self.encode_binary(data),
              }
        if value is not None:
            req['value'] = hex(value)

        gas = int(self._request('eth_estimateGas', req), 16)
        gas = int(float(gas) * self.gas_multiplier)
        req['gas'] = hex(gas)

        req['gasPrice'] = hex(self._get_gas_price())

        transaction_hash = \
            self.decode_hash(self._request('eth_sendTransaction', req))

        block_num = None
        block_hash = None
        timeout_after = time.time() + self.timeout
        while time.time() < timeout_after:
            result = self._request('eth_getTransactionReceipt',
                                   self.encode_hash(transaction_hash))
            if result is None:
                time.sleep(1)
                continue

            if int(result.get(u'status', '0x1'), 16) == 0:
                raise pyethwolf.exceptions.ClientError(
                          'transaction failed (%r)' % (result,))

            block_num = int(result['blockNumber'], 16)
            block_hash = self.decode_hash(result['blockHash'])
            break

        return (transaction_hash, block_num, block_hash)

    def _get_gas_price(self):
        gas_price = int(self._request('eth_gasPrice'), 16)
        return int(float(gas_price) * self.gas_price_multiplier)

    @staticmethod
    def encode_address(s):
        s = s.lower()
        if not s.startswith('0x'):
            s = '0x' + s
        return s

    @staticmethod
    def decode_address(s):
        return s.encode('us-ascii').lower()

    @staticmethod
    def encode_hash(s):
        s = s.lower()
        if not s.startswith('0x'):
            s = '0x' + s
        return s

    @staticmethod
    def decode_hash(s):
        return s.encode('us-ascii').lower()

    @staticmethod
    def encode_binary(s):
        return '0x' + binascii.b2a_hex(s)

    @staticmethod
    def decode_binary(s):
        s = s.encode('us-ascii')
        if not (s.startswith('0x') or s.startswith('0X')):
            raise ValueError(s)
        return binascii.a2b_hex(s[2:])

    def _request(self, cmd, *params):
        # JSON should allow 64 bit signed, for the id, but let's make it
        # 56 bits because it's the easiest way I can think of to make sure
        # we get something unsigned.
        (req_id,) = struct.unpack('!Q', '\x00' + os.urandom(7))

        params = list(params)

        req = {'jsonrpc': self._rpc_ver, 'id': req_id,
               'method': cmd, 'params': params}
        (http_status, resp) = self._raw_request(req)
        try:
            return resp[u'result']
        except KeyError:
            return None

    def _raw_request(self, req):
        req_json = json.dumps(req)
        url_req = \
            urllib2.Request(
                url=self.url, data=req_json,
                headers={'Content-Type': 'application/json'})

        try:
            f = urllib2.urlopen(url_req, timeout=self.timeout)
        except urllib2.HTTPError, e:
            raise pyethwolf.exceptions.Error(
                      'HTTP error %d: %s (URL %s)' %
                      (e.code, e.reason, self.url))
        except urllib2.URLError, e:
            raise pyethwolf.exceptions.Error(
                      '%s (URL %s)' % (e.reason, self.url))
        except EnvironmentError, e:
            raise pyethwolf.exceptions.Error(
                      '%s (URL %s)' % (e, self.url))

        try:
            http_status = f.getcode()
            raw_resp = f.read()
        except urllib2.URLError, e:
            raise pyethwolf.exceptions.Error(
                      '%s (URL %s)' % (e.reason, self.url))
        except EnvironmentError, e:
            raise pyethwolf.exceptions.Error(
                      '%s (URL %s)' % (e, self.url))

        if (http_status < 200) or (http_status > 299):
            raise pyethwolf.exceptions.Error(
                      'HTTP error %d: %r (URL %s)' %
                      (e.code, raw_resp, self.url))

        try:
            resp = json.loads(raw_resp)
            err_dict = resp.get(u'error')
            if err_dict is not None:
                err = err_dict.get(u'message',
                                   u'unknown error').encode('us-ascii')
            else:
                err = None
        except Exception:
            raise pyethwolf.exceptions.Error(
                      'invalid JSON: %r (URL %s)' % (raw_resp, self.url))

        if err is not None:
            raise pyethwolf.exceptions.ClientError(
                      '%s: request was %r (URL %s)' %
                      (err, req_json, self.url))

        return (http_status, resp)

class Contract (object):
    def __init__(self, client, contract_address, abi):
        self.client = client
        self.contract_address = contract_address

        self.funcs = {}
        self.ctor_args_codec = None

        # http://solidity.readthedocs.io/en/v0.4.21/abi-spec.html#json
        for func_spec in abi:
            func_type = func_spec.get('type', 'function')
            # We don't handle events yet, and the fallback function has no
            # args or returns...
            if func_type not in ('function', 'constructor'):
                continue

            args_codec = \
                pyethwolf.abi.make_abi_codec(func_spec.get('inputs', []))
            returns_codec = \
                pyethwolf.abi.make_abi_codec(func_spec.get('outputs', []))

            if func_type == 'function':
                self.funcs[func_spec['name']] = (args_codec, returns_codec)
            elif func_type == 'constructor':
                self.ctor_args_codec = args_codec

    # Parameters:
    #   - `account`: Ethereum address that is doing the inspection
    #   - `func_name`: Name of function to call
    #   - `args`: List of arguments
    # Returns whatever the function returned.
    def inspect(self, account, func_name, args):
        (args_codec, returns_codec) = self.funcs[func_name]
        data = args_codec.truncated_hashed_function_signature(func_name) + \
               args_codec.encode(args)
        return returns_codec.decode(
                   self.client._inspect_contract(
                       account, self.contract_address, data))

    # Parameters:
    #   - `account`: Ethereum address that is doing the mutation
    #   - `func_name`: Name of function to call
    #   - `args`: List of arguments
    #   - `value`: Value (optional)
    # Returns:
    # (`transaction_hash`, `block_num`, `block_hash`), where:
    #   - `transaction_hash`: Transaction hash
    #   - `block_num`: Block number (or None if timeout occurred)
    #   - `block_hash`: Block hash (or None if timeout occurred)
    def mutate(self, account, func_name, args, value=None):
        (args_codec, returns_codec) = self.funcs[func_name]
        data = args_codec.truncated_hashed_function_signature(func_name) + \
               args_codec.encode(args)
        return self.client._mutate_contract(account, self.contract_address,
                                            data, value)
