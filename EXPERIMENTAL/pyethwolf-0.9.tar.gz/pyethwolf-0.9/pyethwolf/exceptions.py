class Error (Exception):
    pass

class ClientError (Error):
    pass
