from setuptools import setup
setup(name='pyethwolf',
      version='0.9',
      description='Wolves think Ethereum is pretty neat! Aroooo!',
      packages=['pyethwolf'],
)
